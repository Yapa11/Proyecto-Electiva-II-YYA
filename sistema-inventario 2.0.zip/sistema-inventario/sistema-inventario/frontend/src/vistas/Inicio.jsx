import DisenoPagina from "../componentes/DisenoPagina";

export default function Inicio({
  negocioActual,
  sesion
}) {
  /*
   * Si por alguna razón todavía no se ha cargado
   * el negocio, mostramos un mensaje en lugar de
   * intentar acceder a datos inexistentes.
   */
  if (!negocioActual) {
    return (
      <DisenoPagina
        titulo="Inicio"
        subtitulo="Resumen del sistema"
      >
        <div className="tarjeta">
          <div className="estado-vacio">
            <div className="estado-vacio-icono">
              !
            </div>

            <h2>
              No se encontró el negocio
            </h2>

            <p>
              No se pudo cargar la información del
              negocio asociado a esta sesión.
            </p>
          </div>
        </div>
      </DisenoPagina>
    );
  }

  const productos =
    negocioActual.productos || [];

  const movimientos =
    negocioActual.movimientos || [];

  const empleados =
    negocioActual.empleados || [];

  /*
   * Productos con stock bajo.
   */
  const productosStockBajo =
    productos.filter(
      (producto) =>
        Number(producto.cantidad) <=
        Number(producto.minimo)
    );

  /*
   * Movimientos recientes.
   */
  const movimientosRecientes =
    movimientos.slice(0, 5);

  /*
   * Total de unidades existentes.
   */
  const totalUnidades =
    productos.reduce(
      (total, producto) =>
        total + Number(producto.cantidad || 0),
      0
    );

  /*
   * Entradas y salidas.
   */
  const totalEntradas =
    movimientos
      .filter(
        (movimiento) =>
          movimiento.tipo === "Entrada"
      )
      .reduce(
        (total, movimiento) =>
          total +
          Number(movimiento.cantidad || 0),
        0
      );

  const totalSalidas =
    movimientos
      .filter(
        (movimiento) =>
          movimiento.tipo === "Salida"
      )
      .reduce(
        (total, movimiento) =>
          total +
          Number(movimiento.cantidad || 0),
        0
      );

  return (
    <DisenoPagina
      titulo={`Bienvenido, ${
        sesion?.nombre || ""
      }`}
      subtitulo={`Resumen de ${
        negocioActual.nombre
      }`}
    >
      {/* Información del negocio */}
      <div className="tarjeta informacion-negocio">
        <div className="informacion-negocio-contenido">
          <div>
            <span className="etiqueta-seccion">
              Negocio
            </span>

            <h2>
              {negocioActual.nombre}
            </h2>

            <p>
              Código del negocio:{" "}
              <strong>
                {negocioActual.codigo}
              </strong>
            </p>
          </div>

          <div className="rol-usuario">
            <span>
              Sesión actual
            </span>

            <strong>
              {sesion?.esDueno
                ? "Dueño"
                : sesion?.esAdministrador
                ? "Administrador"
                : "Empleado"}
            </strong>
          </div>
        </div>
      </div>

      {/* Tarjetas principales */}
      <div className="tarjetas-resumen">
        <div className="tarjeta-resumen">
          <div className="icono-resumen">
            P
          </div>

          <div>
            <span>
              Productos registrados
            </span>

            <strong>
              {productos.length}
            </strong>
          </div>
        </div>

        <div className="tarjeta-resumen">
          <div className="icono-resumen">
            U
          </div>

          <div>
            <span>
              Unidades en inventario
            </span>

            <strong>
              {totalUnidades}
            </strong>
          </div>
        </div>

        <div className="tarjeta-resumen">
          <div className="icono-resumen">
            E
          </div>

          <div>
            <span>
              Entradas
            </span>

            <strong>
              {totalEntradas}
            </strong>
          </div>
        </div>

        <div className="tarjeta-resumen">
          <div className="icono-resumen">
            S
          </div>

          <div>
            <span>
              Salidas
            </span>

            <strong>
              {totalSalidas}
            </strong>
          </div>
        </div>
      </div>

      {/* Productos */}
      <div className="tarjeta">
        <div className="cabecera-seccion">
          <div>
            <h2>
              Productos registrados
            </h2>

            <p>
              Productos actualmente disponibles
              en el inventario.
            </p>
          </div>

          <span className="contador-seccion">
            {productos.length}
          </span>
        </div>

        {productos.length === 0 ? (
          <div className="estado-vacio">
            <div className="estado-vacio-icono">
              P
            </div>

            <h3>
              No hay productos registrados
            </h3>

            <p>
              Este negocio todavía no tiene
              productos registrados.
            </p>
          </div>
        ) : (
          <div className="tabla-contenedor">
            <table className="tabla">
              <thead>
                <tr>
                  <th>Producto</th>
                  <th>Categoría</th>
                  <th>Existencias</th>
                  <th>Stock mínimo</th>
                  <th>Estado</th>
                </tr>
              </thead>

              <tbody>
                {productos.map(
                  (producto) => {
                    const stockBajo =
                      Number(
                        producto.cantidad
                      ) <=
                      Number(
                        producto.minimo
                      );

                    return (
                      <tr
                        key={producto.id}
                      >
                        <td>
                          <strong>
                            {producto.nombre}
                          </strong>
                        </td>

                        <td>
                          {producto.categoria}
                        </td>

                        <td>
                          {producto.cantidad}
                        </td>

                        <td>
                          {producto.minimo}
                        </td>

                        <td>
                          {stockBajo ? (
                            <span className="estado-stock-bajo">
                              Stock bajo
                            </span>
                          ) : (
                            <span className="estado-stock-ok">
                              Disponible
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  }
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Dos columnas */}
      <div className="grid-inicio">
        {/* Stock bajo */}
        <div className="tarjeta">
          <div className="cabecera-seccion">
            <div>
              <h2>
                Productos con stock bajo
              </h2>

              <p>
                Productos que necesitan
                atención.
              </p>
            </div>
          </div>

          {productosStockBajo.length ===
          0 ? (
            <div className="mensaje-estado-ok">
              <strong>
                Inventario en buen estado
              </strong>

              <p>
                No hay productos por debajo
                del stock mínimo.
              </p>
            </div>
          ) : (
            <div className="lista-productos">
              {productosStockBajo.map(
                (producto) => (
                  <div
                    className="item-producto-alerta"
                    key={producto.id}
                  >
                    <div>
                      <strong>
                        {producto.nombre}
                      </strong>

                      <small>
                        Stock actual:{" "}
                        {
                          producto.cantidad
                        }{" "}
                        / mínimo:{" "}
                        {producto.minimo}
                      </small>
                    </div>

                    <span className="estado-stock-bajo">
                      Bajo
                    </span>
                  </div>
                )
              )}
            </div>
          )}
        </div>

        {/* Empleados */}
        <div className="tarjeta">
          <div className="cabecera-seccion">
            <div>
              <h2>
                Usuarios del negocio
              </h2>

              <p>
                Personal registrado.
              </p>
            </div>

            <span className="contador-seccion">
              {empleados.length}
            </span>
          </div>

          {empleados.length ===
          0 ? (
            <div className="estado-vacio">
              <p>
                No hay empleados registrados.
              </p>
            </div>
          ) : (
            <div className="lista-usuarios">
              {empleados.map(
                (empleado) => (
                  <div
                    className="item-usuario"
                    key={empleado.id}
                  >
                    <div className="avatar-usuario">
                      {empleado.nombre
                        .charAt(0)
                        .toUpperCase()}
                    </div>

                    <div>
                      <strong>
                        {empleado.nombre}{" "}
                        {empleado.apellido}
                      </strong>

                      <small>
                        {empleado.correo}
                      </small>
                    </div>

                    {empleado.esAdministrador && (
                      <span className="estado-activo">
                        Administrador
                      </span>
                    )}
                  </div>
                )
              )}
            </div>
          )}
        </div>
      </div>

      {/* Movimientos recientes */}
      <div className="tarjeta">
        <div className="cabecera-seccion">
          <div>
            <h2>
              Movimientos recientes
            </h2>

            <p>
              Últimos movimientos del
              inventario.
            </p>
          </div>

          <span className="contador-seccion">
            {movimientos.length}
          </span>
        </div>

        {movimientosRecientes.length ===
        0 ? (
          <div className="estado-vacio">
            <p>
              No hay movimientos registrados.
            </p>
          </div>
        ) : (
          <div className="tabla-contenedor">
            <table className="tabla">
              <thead>
                <tr>
                  <th>Tipo</th>
                  <th>Producto</th>
                  <th>Cantidad</th>
                  <th>Fecha</th>
                  <th>Usuario</th>
                </tr>
              </thead>

              <tbody>
                {movimientosRecientes.map(
                  (movimiento) => (
                    <tr
                      key={movimiento.id}
                    >
                      <td>
                        {movimiento.tipo ===
                        "Entrada" ? (
                          <span className="movimiento-entrada">
                            Entrada
                          </span>
                        ) : (
                          <span className="movimiento-salida">
                            Salida
                          </span>
                        )}
                      </td>

                      <td>
                        {movimiento.producto}
                      </td>

                      <td>
                        {movimiento.cantidad}
                      </td>

                      <td>
                        {movimiento.fecha}
                      </td>

                      <td>
                        {movimiento.usuario}
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </DisenoPagina>
  );
}