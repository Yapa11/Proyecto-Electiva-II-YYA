import { useState } from "react";
import DisenoPagina from "../componentes/DisenoPagina";

export default function Usuarios({
  usuarios,
  empleados,
  esDueno,
  registrarEmpleado,
  designarAdministrador,
  revocarAdministrador,
  eliminarEmpleado,
  sesion
}) {
  const [mostrarFormulario, setMostrarFormulario] =
    useState(false);

  const [nombre, setNombre] = useState("");
  const [apellido, setApellido] = useState("");
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");

  const [mensaje, setMensaje] = useState("");

  function limpiarFormulario() {
    setNombre("");
    setApellido("");
    setCorreo("");
    setPassword("");
  }

  function guardarEmpleado(e) {
    e.preventDefault();

    setMensaje("");

    const resultado = registrarEmpleado({
      nombre,
      apellido,
      correo,
      password
    });

    if (!resultado) {
      setMensaje(
        "No tienes permisos para registrar empleados."
      );
      return;
    }

    limpiarFormulario();
    setMostrarFormulario(false);

    setMensaje("Empleado registrado correctamente.");
  }

  function convertirAdministrador(id) {
    const resultado = designarAdministrador(id);

    if (resultado) {
      setMensaje(
        "El empleado ahora es administrador del negocio."
      );
    }
  }

  function quitarAdministrador(id) {
    const resultado = revocarAdministrador(id);

    if (resultado) {
      setMensaje(
        "Se quitaron los permisos de administrador."
      );
    }
  }

  function eliminar(id) {
    const confirmar = window.confirm(
      "¿Seguro que deseas eliminar este empleado?"
    );

    if (!confirmar) {
      return;
    }

    eliminarEmpleado(id);
    setMensaje("Empleado eliminado correctamente.");
  }

  return (
    <DisenoPagina
      titulo="Usuarios"
      subtitulo="Consulta y administración de usuarios del negocio"
    >
      {mensaje && (
        <div className="mensaje-exito">
          {mensaje}
        </div>
      )}

      {esDueno && (
        <div className="acciones-pagina">
          <button
            type="button"
            className="boton boton-principal"
            onClick={() =>
              setMostrarFormulario(!mostrarFormulario)
            }
          >
            {mostrarFormulario
              ? "Cancelar"
              : "Registrar empleado"}
          </button>
        </div>
      )}

      {mostrarFormulario && esDueno && (
        <div className="tarjeta formulario-empleado">
          <h2>Registrar nuevo empleado</h2>

          <form onSubmit={guardarEmpleado}>
            <div className="formulario-grid">
              <div>
                <label>Nombre</label>

                <input
                  type="text"
                  value={nombre}
                  onChange={(e) =>
                    setNombre(e.target.value)
                  }
                  required
                />
              </div>

              <div>
                <label>Apellido</label>

                <input
                  type="text"
                  value={apellido}
                  onChange={(e) =>
                    setApellido(e.target.value)
                  }
                  required
                />
              </div>

              <div>
                <label>Correo</label>

                <input
                  type="email"
                  value={correo}
                  onChange={(e) =>
                    setCorreo(e.target.value)
                  }
                  required
                />
              </div>

              <div>
                <label>Contraseña</label>

                <input
                  type="password"
                  value={password}
                  onChange={(e) =>
                    setPassword(e.target.value)
                  }
                  required
                />
              </div>
            </div>

            <div className="acciones-formulario">
              <button
                type="submit"
                className="boton boton-principal"
              >
                Guardar empleado
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="tarjeta">
        <div className="cabecera-panel">
          <div>
            <h2>Usuarios registrados</h2>

            <p>
              Aquí se muestran los usuarios asociados
              al negocio.
            </p>
          </div>
        </div>

        <div className="tabla-contenedor">
          <table className="tabla">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Rol</th>
              </tr>
            </thead>

            <tbody>
              {usuarios.map((usuario) => (
                <tr key={usuario.id}>
                  <td>{usuario.nombre}</td>
                  <td>{usuario.correo}</td>
                  <td>{usuario.rol}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="tarjeta">
        <div className="cabecera-panel">
          <div>
            <h2>Empleados</h2>

            <p>
              El dueño puede designar un empleado como
              administrador del negocio.
            </p>
          </div>
        </div>

        {empleados.length === 0 ? (
          <p className="texto-vacio">
            No hay empleados registrados.
          </p>
        ) : (
          <div className="tabla-contenedor">
            <table className="tabla">
              <thead>
                <tr>
                  <th>Empleado</th>
                  <th>Correo</th>
                  <th>Permisos</th>

                  {esDueno && (
                    <th>Acciones</th>
                  )}
                </tr>
              </thead>

              <tbody>
                {empleados.map((empleado) => (
                  <tr key={empleado.id}>
                    <td>
                      {empleado.nombre}{" "}
                      {empleado.apellido}
                    </td>

                    <td>{empleado.correo}</td>

                    <td>
                      {empleado.esAdministrador ? (
                        <span className="estado-activo">
                          Administrador
                        </span>
                      ) : (
                        <span className="estado-sin">
                          Solo consulta
                        </span>
                      )}
                    </td>

                    {esDueno && (
                      <td>
                        <div className="acciones-tabla">
                          {empleado.esAdministrador ? (
                            <button
                              type="button"
                              className="boton boton-secundario"
                              onClick={() =>
                                quitarAdministrador(
                                  empleado.id
                                )
                              }
                            >
                              Quitar permisos
                            </button>
                          ) : (
                            <button
                              type="button"
                              className="boton boton-principal"
                              onClick={() =>
                                convertirAdministrador(
                                  empleado.id
                                )
                              }
                            >
                              Designar administrador
                            </button>
                          )}

                          <button
                            type="button"
                            className="boton boton-peligro"
                            onClick={() =>
                              eliminar(empleado.id)
                            }
                          >
                            Eliminar
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {!esDueno && (
        <div className="aviso-solo-consulta">
          <strong>Modo de consulta</strong>

          <p>
            Tu cuenta puede consultar la información del
            negocio. Las funciones administrativas están
            disponibles únicamente para el dueño y para
            el empleado designado como administrador.
          </p>
        </div>
      )}

      {sesion?.esAdministrador && !sesion?.esDueno && (
        <div className="aviso-administrador">
          <strong>Administrador del negocio</strong>

          <p>
            Tienes permisos para administrar productos y
            registrar movimientos porque el dueño te
            designó como administrador.
          </p>
        </div>
      )}
    </DisenoPagina>
  );
}