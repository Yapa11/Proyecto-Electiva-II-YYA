import {
  useEffect,
  useState
} from "react";

import {
  Link,
  useNavigate,
  useParams
} from "react-router-dom";

import DisenoPagina from "../componentes/DisenoPagina";

const formularioInicial = {

  nombre: "",

  categoria:
    "Tecnología",

  descripcion: "",

  precio: "",

  stock: "",

  minimo: "",

  proveedor: ""
};

export default function FormularioProducto({
  productos = [],
  guardarProducto,
  sesion,
  cerrarSesion
}) {

  const { id } =
    useParams();

  const navigate =
    useNavigate();

  const [form, setForm] =
    useState(
      formularioInicial
    );

  const editar =
    Boolean(id);

  useEffect(() => {

    if (editar) {

      const existente =
        productos.find(
          (p) =>
            p.id === Number(id)
        );

      if (existente) {
        setForm(existente);
      }

    }

  }, [
    editar,
    id,
    productos
  ]);

  function cambiar(e) {

    setForm({
      ...form,
      [e.target.name]:
        e.target.value
    });
  }

  function guardar(e) {

    e.preventDefault();

    guardarProducto({

      ...form,

      precio:
        Number(form.precio),

      stock:
        Number(form.stock),

      minimo:
        Number(form.minimo)

    });

    navigate(
      "/productos"
    );
  }

  return (

    <DisenoPagina
      titulo={
        editar
          ? "Editar producto"
          : "Registrar producto"
      }
      subtitulo="Completa la información del producto."
      sesion={sesion}
      cerrarSesion={cerrarSesion}
    >

      <div className="tarjeta formulario">

        <form
          onSubmit={guardar}
        >

          <div className="grid-2">

            <div>

              <label>
                Nombre del producto
              </label>

              <input
                name="nombre"
                value={form.nombre}
                onChange={cambiar}
                required
              />

            </div>

            <div>

              <label>
                Categoría
              </label>

              <select
                name="categoria"
                value={
                  form.categoria
                }
                onChange={cambiar}
              >

                <option>
                  Tecnología
                </option>

                <option>
                  Accesorios
                </option>

                <option>
                  Oficina
                </option>

                <option>
                  Otros
                </option>

              </select>

            </div>

          </div>

          <label>
            Descripción
          </label>

          <textarea
            name="descripcion"
            value={
              form.descripcion
            }
            onChange={cambiar}
            rows="4"
          />

          <div className="grid-2">

            <div>

              <label>
                Precio
              </label>

              <input
                type="number"
                name="precio"
                value={form.precio}
                onChange={cambiar}
                min="0"
                required
              />

            </div>

            <div>

              <label>
                Stock inicial
              </label>

              <input
                type="number"
                name="stock"
                value={form.stock}
                onChange={cambiar}
                min="0"
                required
              />

            </div>

            <div>

              <label>
                Stock mínimo
              </label>

              <input
                type="number"
                name="minimo"
                value={form.minimo}
                onChange={cambiar}
                min="0"
                required
              />

            </div>

            <div>

              <label>
                Proveedor
              </label>

              <input
                name="proveedor"
                value={
                  form.proveedor
                }
                onChange={cambiar}
                required
              />

            </div>

          </div>

          <div className="acciones">

            <Link
              className="boton boton-secundario"
              to="/productos"
            >
              Cancelar
            </Link>

            <button
              className="boton boton-principal"
              type="submit"
            >
              {editar
                ? "Guardar cambios"
                : "Registrar producto"}
            </button>

          </div>

        </form>

      </div>

    </DisenoPagina>
  );
}