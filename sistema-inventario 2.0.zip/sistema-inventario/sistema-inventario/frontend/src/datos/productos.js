const productos = [

  {
    id: 1,
    nombre: "Laptop Lenovo",
    categoria: "Tecnología",
    descripcion: "Computador portátil para trabajo administrativo.",
    precio: 2500000,
    stock: 24,
    minimo: 5,
    proveedor: "TecnoSoluciones"
  },

  {
    id: 2,
    nombre: "Mouse inalámbrico",
    categoria: "Accesorios",
    descripcion: "Mouse inalámbrico USB.",
    precio: 65000,
    stock: 12,
    minimo: 5,
    proveedor: "CompuMarket"
  },

  {
    id: 3,
    nombre: "Teclado USB",
    categoria: "Accesorios",
    descripcion: "Teclado USB estándar.",
    precio: 80000,
    stock: 18,
    minimo: 6,
    proveedor: "CompuMarket"
  },

  {
    id: 4,
    nombre: "Monitor 24 pulgadas",
    categoria: "Tecnología",
    descripcion: "Monitor LED Full HD.",
    precio: 720000,
    stock: 4,
    minimo: 5,
    proveedor: "TecnoSoluciones"
  }

];

export default productos;