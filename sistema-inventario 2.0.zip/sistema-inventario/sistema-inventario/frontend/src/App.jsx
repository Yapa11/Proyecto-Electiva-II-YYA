import { useEffect, useState } from "react";
import RutasAplicacion from "./rutas/RutasAplicacion";

const negociosIniciales = [
  {
    codigo: "NEG001",
    nombre: "TecnoQuibdó",
    propietario: {
      nombre: "Dueño TecnoQuibdó",
      correo: "dueno@tecnoquibdo.com",
      password: "123456"
    },
    empleados: [
      {
        id: 1,
        nombre: "Ana",
        apellido: "Empleado",
        correo: "ana@tecnoquibdo.com",
        password: "123456",
        esAdministrador: false
      }
    ],
    productos: [
      {
        id: 1,
        nombre: "Laptop Lenovo",
        categoria: "Computadores",
        cantidad: 10,
        minimo: 3,
        precio: 2500000
      },
      {
        id: 2,
        nombre: "Mouse inalámbrico",
        categoria: "Accesorios",
        cantidad: 25,
        minimo: 5,
        precio: 65000
      },
      {
        id: 3,
        nombre: "Teclado USB",
        categoria: "Accesorios",
        cantidad: 18,
        minimo: 5,
        precio: 85000
      },
      {
        id: 4,
        nombre: "Monitor 24 pulgadas",
        categoria: "Monitores",
        cantidad: 8,
        minimo: 2,
        precio: 720000
      }
    ],
    movimientos: [
      {
        id: 1,
        tipo: "Entrada",
        producto: "Laptop Lenovo",
        cantidad: 5,
        fecha: "2026-09-20",
        usuario: "Dueño TecnoQuibdó"
      },
      {
        id: 2,
        tipo: "Salida",
        producto: "Mouse inalámbrico",
        cantidad: 2,
        fecha: "2026-09-21",
        usuario: "Dueño TecnoQuibdó"
      }
    ]
  },

  {
    codigo: "NEG002",
    nombre: "Comercial Chocó",
    propietario: {
      nombre: "Dueño Comercial Chocó",
      correo: "dueno@comercialchoco.com",
      password: "123456"
    },
    empleados: [
      {
        id: 1,
        nombre: "Carlos",
        apellido: "Empleado",
        correo: "carlos@comercialchoco.com",
        password: "123456",
        esAdministrador: false
      }
    ],
    productos: [
      {
        id: 1,
        nombre: "Impresora Epson",
        categoria: "Impresoras",
        cantidad: 7,
        minimo: 2,
        precio: 850000
      },
      {
        id: 2,
        nombre: "Resma de papel",
        categoria: "Papelería",
        cantidad: 40,
        minimo: 10,
        precio: 18000
      },
      {
        id: 3,
        nombre: "Tinta negra",
        categoria: "Consumibles",
        cantidad: 12,
        minimo: 3,
        precio: 55000
      }
    ],
    movimientos: [
      {
        id: 1,
        tipo: "Entrada",
        producto: "Resma de papel",
        cantidad: 20,
        fecha: "2026-09-20",
        usuario: "Dueño Comercial Chocó"
      }
    ]
  }
];

const claveNegocios = "sgi_negocios";

function obtenerNegociosGuardados() {
  try {
    const datos = localStorage.getItem(claveNegocios);

    if (datos) {
      const negocios = JSON.parse(datos);

      if (Array.isArray(negocios) && negocios.length > 0) {
        return negocios;
      }
    }
  } catch (error) {
    console.error("Error al cargar los negocios:", error);
  }

  return negociosIniciales;
}

export default function App() {
  const [negocios, setNegocios] = useState(obtenerNegociosGuardados);
  const [sesion, setSesion] = useState(null);
  const [negocioActual, setNegocioActual] = useState(null);

  /*
   * Guarda permanentemente los negocios en el navegador.
   *
   * Esto permite que:
   * - la designación de administrador no se pierda;
   * - los empleados registrados no se pierdan;
   * - los productos modificados permanezcan;
   * - los movimientos registrados permanezcan.
   */
  useEffect(() => {
    localStorage.setItem(claveNegocios, JSON.stringify(negocios));
  }, [negocios]);

  /*
   * Recuperamos la sesión si existe.
   * La sesión se mantiene solamente durante la sesión del navegador.
   */
  useEffect(() => {
    try {
      const sesionGuardada = sessionStorage.getItem("sesion");

      if (sesionGuardada) {
        const datos = JSON.parse(sesionGuardada);

        setSesion(datos);

        if (datos.codigoNegocio) {
          const negocio = negocios.find(
            (item) => item.codigo === datos.codigoNegocio
          );

          setNegocioActual(negocio || null);
        }
      }
    } catch (error) {
      console.error("Error al recuperar la sesión:", error);
      sessionStorage.removeItem("sesion");
    }
  }, []);

  /*
   * Iniciar sesión.
   *
   * Hay tres tipos:
   * 1. Dueño
   * 2. Empleado
   * 3. Administrador global
   */
  function iniciarSesion(datos) {
    const {
      codigoNegocio,
      correo,
      password,
      tipoAcceso
    } = datos;

    /*
     * ADMINISTRADOR GLOBAL
     *
     * Este usuario pertenece al sistema, no a un negocio.
     */
    if (tipoAcceso === "administrador") {
      if (
        correo === "admin@sgi.com" &&
        password === "123456"
      ) {
        const nuevaSesion = {
          tipo: "administrador",
          nombre: "Administrador Global",
          correo,
          puedeConsultarNegocios: true,
          puedeModificarNegocios: false
        };

        setSesion(nuevaSesion);
        setNegocioActual(null);

        sessionStorage.setItem(
          "sesion",
          JSON.stringify(nuevaSesion)
        );

        return {
          correcto: true,
          ruta: "/administrador"
        };
      }

      return {
        correcto: false,
        mensaje: "Correo o contraseña incorrectos para el administrador."
      };
    }

    /*
     * DUEÑO Y EMPLEADO
     *
     * Ambos deben indicar el código del negocio.
     */
    const negocio = negocios.find(
      (item) =>
        item.codigo.toUpperCase() ===
        String(codigoNegocio).trim().toUpperCase()
    );

    if (!negocio) {
      return {
        correcto: false,
        mensaje: "El código del negocio no existe."
      };
    }

    /*
     * LOGIN DEL DUEÑO
     */
    if (tipoAcceso === "dueno") {
      const correoNormalizado = correo.trim().toLowerCase();

      if (
        negocio.propietario.correo.toLowerCase() ===
          correoNormalizado &&
        negocio.propietario.password === password
      ) {
        const nuevaSesion = {
          tipo: "dueno",
          codigoNegocio: negocio.codigo,
          nombre: negocio.propietario.nombre,
          correo: negocio.propietario.correo,
          esDueno: true,
          puedeAdministrar: true,
          puedeConsultarNegocios: true,
          puedeModificarNegocios: true
        };

        setSesion(nuevaSesion);
        setNegocioActual(negocio);

        sessionStorage.setItem(
          "sesion",
          JSON.stringify(nuevaSesion)
        );

        return {
          correcto: true,
          ruta: "/inicio"
        };
      }

      return {
        correcto: false,
        mensaje: "Correo o contraseña incorrectos."
      };
    }

    /*
     * LOGIN DEL EMPLEADO
     */
    if (tipoAcceso === "empleado") {
      const correoNormalizado = correo.trim().toLowerCase();

      const empleado = negocio.empleados.find(
        (item) =>
          item.correo.toLowerCase() === correoNormalizado &&
          item.password === password
      );

      if (!empleado) {
        return {
          correcto: false,
          mensaje: "Correo o contraseña incorrectos."
        };
      }

      const nuevaSesion = {
        tipo: "empleado",
        codigoNegocio: negocio.codigo,
        nombre: `${empleado.nombre} ${empleado.apellido}`,
        correo: empleado.correo,
        esDueno: false,

        /*
         * Aquí está la parte importante:
         *
         * Si el dueño designó a este empleado como administrador,
         * tendrá permisos administrativos.
         */
        puedeAdministrar: empleado.esAdministrador === true,

        esAdministrador: empleado.esAdministrador === true,

        puedeConsultarNegocios: true,

        puedeModificarNegocios:
          empleado.esAdministrador === true
      };

      setSesion(nuevaSesion);
      setNegocioActual(negocio);

      sessionStorage.setItem(
        "sesion",
        JSON.stringify(nuevaSesion)
      );

      return {
        correcto: true,
        ruta: "/inicio"
      };
    }

    return {
      correcto: false,
      mensaje: "Tipo de acceso no válido."
    };
  }

  /*
   * Cerrar sesión.
   *
   * IMPORTANTE:
   * NO borramos localStorage.
   *
   * De esta manera la designación del administrador
   * permanece guardada.
   */
  function cerrarSesion() {
    setSesion(null);
    setNegocioActual(null);

    sessionStorage.removeItem("sesion");
  }

  /*
   * Actualiza un negocio y lo guarda en localStorage.
   */
  function actualizarNegocio(codigo, cambios) {
    setNegocios((anteriores) =>
      anteriores.map((negocio) =>
        negocio.codigo === codigo
          ? {
              ...negocio,
              ...cambios
            }
          : negocio
      )
    );
  }

  /*
   * Guardar producto.
   */
  function guardarProducto(producto) {
    if (!sesion?.puedeAdministrar || !negocioActual) {
      return false;
    }

    const productosActualizados = [
      ...(negocioActual.productos || [])
    ];

    const indice = productosActualizados.findIndex(
      (item) => Number(item.id) === Number(producto.id)
    );

    if (indice >= 0) {
      productosActualizados[indice] = {
        ...productosActualizados[indice],
        ...producto
      };
    } else {
      productosActualizados.push({
        ...producto,
        id: Date.now()
      });
    }

    actualizarNegocio(negocioActual.codigo, {
      productos: productosActualizados
    });

    const negocioActualizado = {
      ...negocioActual,
      productos: productosActualizados
    };

    setNegocioActual(negocioActualizado);

    return true;
  }

  /*
   * Eliminar producto.
   */
  function eliminarProducto(id) {
    if (!sesion?.puedeAdministrar || !negocioActual) {
      return false;
    }

    const productosActualizados = (
      negocioActual.productos || []
    ).filter((producto) => Number(producto.id) !== Number(id));

    actualizarNegocio(negocioActual.codigo, {
      productos: productosActualizados
    });

    setNegocioActual({
      ...negocioActual,
      productos: productosActualizados
    });

    return true;
  }

  /*
   * Registrar entrada o salida.
   */
  function registrarMovimiento(movimiento) {
    if (!sesion?.puedeAdministrar || !negocioActual) {
      return false;
    }

    const productosActualizados = [
      ...(negocioActual.productos || [])
    ];

    const producto = productosActualizados.find(
      (item) =>
        String(item.nombre).toLowerCase() ===
        String(movimiento.producto).toLowerCase()
    );

    if (!producto) {
      return false;
    }

    const cantidad = Number(movimiento.cantidad);

    if (!Number.isFinite(cantidad) || cantidad <= 0) {
      return false;
    }

    if (
      movimiento.tipo === "Salida" &&
      producto.cantidad < cantidad
    ) {
      return false;
    }

    if (movimiento.tipo === "Entrada") {
      producto.cantidad += cantidad;
    }

    if (movimiento.tipo === "Salida") {
      producto.cantidad -= cantidad;
    }

    const nuevoMovimiento = {
      ...movimiento,
      id: Date.now(),
      cantidad,
      fecha:
        movimiento.fecha ||
        new Date().toISOString().slice(0, 10),
      usuario: sesion.nombre
    };

    const movimientosActualizados = [
      nuevoMovimiento,
      ...(negocioActual.movimientos || [])
    ];

    actualizarNegocio(negocioActual.codigo, {
      productos: productosActualizados,
      movimientos: movimientosActualizados
    });

    setNegocioActual({
      ...negocioActual,
      productos: productosActualizados,
      movimientos: movimientosActualizados
    });

    return true;
  }

  /*
   * Registrar empleado.
   */
  function registrarEmpleado(empleado) {
    if (!sesion?.esDueno || !negocioActual) {
      return false;
    }

    const nuevoEmpleado = {
      ...empleado,
      id: Date.now(),
      esAdministrador: false
    };

    const empleadosActualizados = [
      ...(negocioActual.empleados || []),
      nuevoEmpleado
    ];

    actualizarNegocio(negocioActual.codigo, {
      empleados: empleadosActualizados
    });

    setNegocioActual({
      ...negocioActual,
      empleados: empleadosActualizados
    });

    return true;
  }

  /*
   * Designar administrador.
   *
   * Solo el dueño puede hacer esto.
   *
   * Solo puede existir un administrador de negocio.
   */
  function designarAdministrador(idEmpleado) {
    if (!sesion?.esDueno || !negocioActual) {
      return false;
    }

    const empleadosActualizados = (
      negocioActual.empleados || []
    ).map((empleado) => ({
      ...empleado,
      esAdministrador:
        Number(empleado.id) === Number(idEmpleado)
    }));

    actualizarNegocio(negocioActual.codigo, {
      empleados: empleadosActualizados
    });

    setNegocioActual({
      ...negocioActual,
      empleados: empleadosActualizados
    });

    return true;
  }

  /*
   * Quitar permisos de administrador.
   */
  function revocarAdministrador(idEmpleado) {
    if (!sesion?.esDueno || !negocioActual) {
      return false;
    }

    const empleadosActualizados = (
      negocioActual.empleados || []
    ).map((empleado) =>
      Number(empleado.id) === Number(idEmpleado)
        ? {
            ...empleado,
            esAdministrador: false
          }
        : empleado
    );

    actualizarNegocio(negocioActual.codigo, {
      empleados: empleadosActualizados
    });

    setNegocioActual({
      ...negocioActual,
      empleados: empleadosActualizados
    });

    return true;
  }

  /*
   * Elimina un empleado.
   */
  function eliminarEmpleado(idEmpleado) {
    if (!sesion?.esDueno || !negocioActual) {
      return false;
    }

    const empleadosActualizados = (
      negocioActual.empleados || []
    ).filter(
      (empleado) =>
        Number(empleado.id) !== Number(idEmpleado)
    );

    actualizarNegocio(negocioActual.codigo, {
      empleados: empleadosActualizados
    });

    setNegocioActual({
      ...negocioActual,
      empleados: empleadosActualizados
    });

    return true;
  }

  /*
   * Usuarios del negocio.
   */
  const usuarios = negocioActual
    ? [
        {
          id: "dueno",
          nombre: negocioActual.propietario.nombre,
          correo: negocioActual.propietario.correo,
          rol: "Dueño"
        },
        ...(negocioActual.empleados || []).map(
          (empleado) => ({
            id: empleado.id,
            nombre: `${empleado.nombre} ${empleado.apellido}`,
            correo: empleado.correo,
            rol: empleado.esAdministrador
              ? "Administrador"
              : "Empleado"
          })
        )
      ]
    : [];

  const empleados = negocioActual?.empleados || [];

  return (
    <RutasAplicacion
      sesion={sesion}
      negocioActual={negocioActual}
      negocios={negocios}
      usuarios={usuarios}
      empleados={empleados}
      iniciarSesion={iniciarSesion}
      cerrarSesion={cerrarSesion}
      guardarProducto={guardarProducto}
      eliminarProducto={eliminarProducto}
      registrarMovimiento={registrarMovimiento}
      registrarEmpleado={registrarEmpleado}
      designarAdministrador={designarAdministrador}
      revocarAdministrador={revocarAdministrador}
      eliminarEmpleado={eliminarEmpleado}
    />
  );
}