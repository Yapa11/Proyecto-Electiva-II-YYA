from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.rutas.productos import router as productos_router


# Creamos la aplicación principal.
app = FastAPI(
    title="API del Sistema de Gestión de Inventario",
    description="API para consultar productos de una fuente pública de prueba.",
    version="1.0.0"
)


# Permitimos que el frontend desarrollado con React
# pueda realizar solicitudes al backend.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


# Registramos las rutas relacionadas con los productos.
app.include_router(productos_router)


# Ruta inicial para comprobar que el servidor funciona.
@app.get("/")
def inicio():
    return {
        "mensaje": "API del Sistema de Gestión de Inventario funcionando correctamente."
    }


# Ruta para comprobar el estado del servicio.
@app.get("/api/estado")
def consultar_estado():
    return {
        "estado": "activo",
        "proyecto": "Sistema de Gestión de Inventario"
    }