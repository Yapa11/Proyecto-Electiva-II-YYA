import httpx

from fastapi import APIRouter, HTTPException


# Creamos un grupo de rutas para las operaciones de productos.
router = APIRouter(
    prefix="/api/productos",
    tags=["Productos"]
)


# Dirección de la API pública de prueba.
API_PUBLICA_PRODUCTOS = "https://dummyjson.com/products"


@router.get("/")
async def consultar_productos():
    """
    Consulta productos en DummyJSON y devuelve los datos
    necesarios para la vista de productos del frontend.
    """

    try:
        # Creamos un cliente HTTP para consultar la API externa.
        async with httpx.AsyncClient(timeout=15.0) as cliente:

            respuesta = await cliente.get(
                API_PUBLICA_PRODUCTOS,
                params={"limit": 30}
            )

            # Si el servicio externo responde con un error,
            # lo detectamos.
            respuesta.raise_for_status()

            # Convertimos la respuesta JSON en datos de Python.
            contenido = respuesta.json()

        # Comprobamos que la respuesta tenga la estructura esperada.
        if not isinstance(contenido, dict):
            raise HTTPException(
                status_code=502,
                detail="La API externa devolvió una respuesta no válida."
            )

        lista_productos = contenido.get("products")

        if not isinstance(lista_productos, list):
            raise HTTPException(
                status_code=502,
                detail="No se encontró la lista de productos en la respuesta."
            )

        # Adaptamos los nombres de los campos al contexto
        # del sistema de gestión de inventario.
        productos_adaptados = []

        for producto in lista_productos:
            productos_adaptados.append({
                "id": producto.get("id"),
                "nombre": producto.get("title", "Sin nombre"),
                "descripcion": producto.get("description", ""),
                "categoria": producto.get("category", "Sin categoría"),
                "precio": producto.get("price", 0),
                "existencias": producto.get("stock", 0),
                "imagen": producto.get("thumbnail", "")
            })

        # Devolvemos los productos y algunos metadatos
        # útiles para la interfaz.
        return {
            "origen": "DummyJSON",
            "total": contenido.get("total", len(productos_adaptados)),
            "cantidad_recibida": len(productos_adaptados),
            "productos": productos_adaptados
        }

    except httpx.TimeoutException:
        raise HTTPException(
            status_code=504,
            detail="La consulta a la API externa superó el tiempo de espera."
        )

    except httpx.HTTPStatusError:
        raise HTTPException(
            status_code=502,
            detail="La API externa respondió con un error."
        )

    except httpx.RequestError:
        raise HTTPException(
            status_code=502,
            detail="No fue posible conectarse con la API externa."
        )

    except ValueError:
        raise HTTPException(
            status_code=502,
            detail="La API externa no devolvió un JSON válido."
        )