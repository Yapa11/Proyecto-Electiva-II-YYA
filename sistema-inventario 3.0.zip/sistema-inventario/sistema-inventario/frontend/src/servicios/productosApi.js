// Servicio encargado de consultar los productos de la API.
// La vista de React utilizará estas funciones para obtener los datos.

const API_URL = "http://127.0.0.1:8000/api/productos/";

// Consultar los productos de la API.
export async function obtenerProductosApi() {
    const respuesta = await fetch(API_URL);

    if (!respuesta.ok) {
        throw new Error("No fue posible obtener los productos de la API.");
    }

    const datos = await respuesta.json();

    // Comprobar que la respuesta tenga la lista de productos esperada.
    if (!Array.isArray(datos.productos)) {
        throw new Error("La respuesta de la API no contiene una lista válida de productos.");
    }

    return datos.productos;
}