import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import DisenoPagina from "../componentes/DisenoPagina";
import { obtenerProductosApi } from "../servicios/productosApi";

export default function Productos({
  productos = [],
  puedeAdministrar,
  eliminarProducto,
  sesion
}) {
  const navigate = useNavigate();

  // Estados del inventario del negocio.
  const [busqueda, setBusqueda] = useState("");
  const [filtro, setFiltro] = useState("todos");

  // Estados para consumir la API pública.
  const [productosApi, setProductosApi] = useState([]);
  const [cargandoApi, setCargandoApi] = useState(true);
  const [errorApi, setErrorApi] = useState("");
  const [busquedaApi, setBusquedaApi] = useState("");

  // Consultar los productos de la API al cargar la vista.
  async function cargarProductosApi() {
    setCargandoApi(true);
    setErrorApi("");

    try {
      const datos = await obtenerProductosApi();
      setProductosApi(datos);
    } catch (error) {
      console.error("Error al consultar la API:", error);

      setErrorApi(
        error.message ||
          "No fue posible consultar los productos de prueba."
      );

      setProductosApi([]);
    } finally {
      setCargandoApi(false);
    }
  }

  useEffect(() => {
    cargarProductosApi();
  }, []);

  // Filtrar los productos reales del inventario del negocio.
  const productosFiltrados = useMemo(() => {
    const texto = busqueda.toLowerCase().trim();

    return productos.filter((producto) => {
      const coincideBusqueda =
        !texto ||
        String(producto.nombre || "")
          .toLowerCase()
          .includes(texto) ||
        String(producto.codigo || "")
          .toLowerCase()
          .includes(texto) ||
        String(producto.categoria || "")
          .toLowerCase()
          .includes(texto);

      const cantidad = Number(producto.cantidad || 0);
      const minimo = Number(producto.minimo || 0);

      let coincideFiltro = true;

      if (filtro === "disponibles") {
        coincideFiltro = cantidad > minimo;
      }

      if (filtro === "stock-bajo") {
        coincideFiltro = cantidad <= minimo;
      }

      return coincideBusqueda && coincideFiltro;
    });
  }, [productos, busqueda, filtro]);

  // Filtrar únicamente los productos recibidos desde la API.
  const productosApiFiltrados = useMemo(() => {
    const texto = busquedaApi.toLowerCase().trim();

    return productosApi.filter((producto) => {
      return (
        String(producto.nombre || "")
          .toLowerCase()
          .includes(texto) ||
        String(producto.categoria || "")
          .toLowerCase()
          .includes(texto) ||
        String(producto.descripcion || "")
          .toLowerCase()
          .includes(texto)
      );
    });
  }, [productosApi, busquedaApi]);

  // Eliminar productos del inventario del negocio.
  function manejarEliminar(producto) {
    const confirmar = window.confirm(
      `¿Deseas eliminar el producto "${producto.nombre}"?`
    );

    if (!confirmar) {
      return;
    }

    eliminarProducto(producto.id);
  }

  return (
    <DisenoPagina
      titulo="Productos"
      subtitulo={`Inventario de ${
        sesion?.nombreNegocio || "tu negocio"
      }`}
    >
      {/* ================================================== */}
      {/* INVENTARIO REAL DEL NEGOCIO */}
      {/* ================================================== */}

      <div className="tarjeta">
        <div className="cabecera-seccion">
          <div>
            <h2>Productos registrados</h2>

            <p>
              Consulta y administra los productos del inventario
              de tu negocio.
            </p>
          </div>

          <div className="acciones">
            {puedeAdministrar && (
              <button
                type="button"
                className="boton boton-principal"
                onClick={() => navigate("/productos/nuevo")}
              >
                + Nuevo producto
              </button>
            )}
          </div>
        </div>

        <div className="aviso-solo-consulta">
          {puedeAdministrar ? (
            <p>
              Tienes permisos para registrar, modificar y eliminar
              productos.
            </p>
          ) : (
            <p>
              Estás en modo de consulta. Puedes visualizar los
              productos, pero no modificarlos.
            </p>
          )}
        </div>
      </div>

      {/* Buscador y filtros del inventario real */}
      <div className="tarjeta">
        <div className="cabecera-seccion">
          <div>
            <h2>Buscar productos</h2>

            <p>
              Utiliza el buscador o el filtro para encontrar
              productos de tu negocio.
            </p>
          </div>

          <span className="contador-seccion">
            {productosFiltrados.length}
          </span>
        </div>

        <div className="filtros-panel">
          <div>
            <label htmlFor="buscar-producto">
              Buscar
            </label>

            <input
              id="buscar-producto"
              type="text"
              placeholder="Buscar por nombre, código o categoría..."
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
            />
          </div>

          <div>
            <label htmlFor="filtro-producto">
              Filtrar por estado
            </label>

            <select
              id="filtro-producto"
              value={filtro}
              onChange={(e) => setFiltro(e.target.value)}
            >
              <option value="todos">Todos</option>

              <option value="disponibles">
                Stock disponible
              </option>

              <option value="stock-bajo">
                Stock bajo
              </option>
            </select>
          </div>
        </div>
      </div>

      {/* Tabla del inventario real */}
      <div className="tarjeta">
        <div className="cabecera-seccion">
          <div>
            <h2>Inventario</h2>

            <p>
              Lista de productos registrados en el negocio.
            </p>
          </div>
        </div>

        {productosFiltrados.length === 0 ? (
          <div className="estado-vacio">
            <div className="estado-vacio-icono">P</div>

            <h3>No se encontraron productos</h3>

            <p>
              No hay productos que coincidan con la búsqueda
              o el filtro seleccionado.
            </p>

            {puedeAdministrar && productos.length === 0 && (
              <button
                type="button"
                className="boton boton-principal"
                onClick={() => navigate("/productos/nuevo")}
                style={{ marginTop: "15px" }}
              >
                Registrar primer producto
              </button>
            )}
          </div>
        ) : (
          <div className="tabla-contenedor">
            <table className="tabla">
              <thead>
                <tr>
                  <th>Código</th>
                  <th>Producto</th>
                  <th>Categoría</th>
                  <th>Precio</th>
                  <th>Existencias</th>
                  <th>Stock mínimo</th>
                  <th>Estado</th>

                  {puedeAdministrar && <th>Acciones</th>}
                </tr>
              </thead>

              <tbody>
                {productosFiltrados.map((producto) => {
                  const cantidad = Number(
                    producto.cantidad || 0
                  );

                  const minimo = Number(
                    producto.minimo || 0
                  );

                  const stockBajo = cantidad <= minimo;

                  return (
                    <tr key={producto.id}>
                      <td>
                        {producto.codigo || `PRO-${producto.id}`}
                      </td>

                      <td>
                        <strong>{producto.nombre}</strong>
                      </td>

                      <td>
                        {producto.categoria || "Sin categoría"}
                      </td>

                      <td>
                        $
                        {Number(
                          producto.precio || 0
                        ).toLocaleString("es-CO")}
                      </td>

                      <td>
                        <strong>{cantidad}</strong>
                      </td>

                      <td>{minimo}</td>

                      <td>
                        {stockBajo ? (
                          <span className="estado-stock-bajo">
                            Stock bajo
                          </span>
                        ) : (
                          <span className="estado-stock-ok">
                            Disponible
                          </span>
                        )}
                      </td>

                      {puedeAdministrar && (
                        <td>
                          <div className="acciones-tabla">
                            <button
                              type="button"
                              className="boton boton-secundario"
                              onClick={() =>
                                navigate(
                                  `/productos/editar/${producto.id}`
                                )
                              }
                            >
                              Editar
                            </button>

                            <button
                              type="button"
                              className="boton boton-peligro"
                              onClick={() =>
                                manejarEliminar(producto)
                              }
                            >
                              Eliminar
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Resumen del inventario real */}
      <div className="tarjetas-resumen">
        <div className="tarjeta-resumen">
          <div className="icono-resumen">P</div>

          <div>
            <span>Total de productos</span>

            <strong>{productos.length}</strong>
          </div>
        </div>

        <div className="tarjeta-resumen">
          <div className="icono-resumen">U</div>

          <div>
            <span>Total de unidades</span>

            <strong>
              {productos.reduce(
                (total, producto) =>
                  total + Number(producto.cantidad || 0),
                0
              )}
            </strong>
          </div>
        </div>

        <div className="tarjeta-resumen">
          <div className="icono-resumen">!</div>

          <div>
            <span>Productos con stock bajo</span>

            <strong>
              {
                productos.filter(
                  (producto) =>
                    Number(producto.cantidad || 0) <=
                    Number(producto.minimo || 0)
                ).length
              }
            </strong>
          </div>
        </div>

        <div className="tarjeta-resumen">
          <div className="icono-resumen">A</div>

          <div>
            <span>Estado</span>

            <strong style={{ fontSize: "18px" }}>
              Activo
            </strong>
          </div>
        </div>
      </div>

      {/* ================================================== */}
      {/* PRODUCTOS DE PRUEBA RECIBIDOS DESDE LA API */}
      {/* ================================================== */}

      <div className="tarjeta" style={{ marginTop: "28px" }}>
        <div className="cabecera-seccion">
          <div>
            <h2>Productos de prueba de la API</h2>

            <p>
              Información externa obtenida mediante nuestro
              backend desde DummyJSON. Estos datos son de
              demostración y no pertenecen al inventario real
              de tu negocio.
            </p>
          </div>

          <button
            type="button"
            className="boton boton-secundario"
            onClick={cargarProductosApi}
            disabled={cargandoApi}
          >
            {cargandoApi ? "Consultando..." : "Actualizar API"}
          </button>
        </div>

        {/* Estado de carga */}
        {cargandoApi && (
          <div
            className="estado-vacio"
            role="status"
            aria-live="polite"
          >
            <h3>Consultando productos...</h3>

            <p>
              Estamos obteniendo la información desde la API.
              Por favor, espera un momento.
            </p>
          </div>
        )}

        {/* Estado de error */}
        {!cargandoApi && errorApi && (
          <div className="estado-vacio" role="alert">
            <h3>No fue posible cargar los productos</h3>

            <p>{errorApi}</p>

            <p>
              Verifica que el backend esté funcionando y que
              tengas conexión a Internet.
            </p>

            <button
              type="button"
              className="boton boton-principal"
              onClick={cargarProductosApi}
              style={{ marginTop: "15px" }}
            >
              Intentar nuevamente
            </button>
          </div>
        )}

        {/* Estado sin resultados */}
        {!cargandoApi &&
          !errorApi &&
          productosApi.length === 0 && (
            <div className="estado-vacio">
              <h3>No hay productos disponibles</h3>

              <p>
                La API respondió correctamente, pero no devolvió
                productos para mostrar.
              </p>
            </div>
          )}

        {/* Resultados de la API */}
        {!cargandoApi &&
          !errorApi &&
          productosApi.length > 0 && (
            <>
              <div className="filtros-panel">
                <div>
                  <label htmlFor="buscar-producto-api">
                    Buscar en los productos de prueba
                  </label>

                  <input
                    id="buscar-producto-api"
                    type="text"
                    placeholder="Buscar por nombre, categoría o descripción..."
                    value={busquedaApi}
                    onChange={(e) =>
                      setBusquedaApi(e.target.value)
                    }
                  />
                </div>

                <div>
                  <label>Productos recibidos</label>

                  <div
                    className="contador-seccion"
                    aria-live="polite"
                  >
                    {productosApiFiltrados.length} de{" "}
                    {productosApi.length}
                  </div>
                </div>
              </div>

              {productosApiFiltrados.length === 0 ? (
                <div className="estado-vacio">
                  <h3>No se encontraron coincidencias</h3>

                  <p>
                    Prueba con otro nombre o categoría.
                  </p>
                </div>
              ) : (
                <div className="tabla-contenedor">
                  <table className="tabla">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Imagen</th>
                        <th>Producto</th>
                        <th>Categoría</th>
                        <th>Precio de prueba</th>
                        <th>Existencias de prueba</th>
                      </tr>
                    </thead>

                    <tbody>
                      {productosApiFiltrados.map((producto) => (
                        <tr key={producto.id}>
                          <td>{producto.id}</td>

                          <td>
                            {producto.imagen ? (
                              <img
                                src={producto.imagen}
                                alt={producto.nombre}
                                loading="lazy"
                                width="55"
                                height="55"
                                style={{
                                  objectFit: "contain",
                                  borderRadius: "6px"
                                }}
                              />
                            ) : (
                              "Sin imagen"
                            )}
                          </td>

                          <td>
                            <strong>{producto.nombre}</strong>

                            {producto.descripcion && (
                              <p
                                style={{
                                  maxWidth: "300px",
                                  fontSize: "12px",
                                  marginTop: "5px"
                                }}
                              >
                                {producto.descripcion}
                              </p>
                            )}
                          </td>

                          <td>
                            {producto.categoria || "Sin categoría"}
                          </td>

                          <td>
                            $
                            {Number(
                              producto.precio || 0
                            ).toLocaleString("es-CO", {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2
                            })}
                          </td>

                          <td>
                            {Number(producto.existencias || 0)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <p
                style={{
                  marginTop: "15px",
                  fontSize: "13px"
                }}
              >
                Fuente de datos: DummyJSON. Los precios y las
                existencias mostrados son datos de demostración.
                No modifican el inventario del negocio.
              </p>
            </>
          )}
      </div>
    </DisenoPagina>
  );
}