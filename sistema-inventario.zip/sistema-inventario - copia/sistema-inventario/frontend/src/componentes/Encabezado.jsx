import { NavLink, useNavigate } from "react-router-dom";

export default function Encabezado() {
  const navigate = useNavigate();

  function cerrarSesion() {
    sessionStorage.clear();
    localStorage.removeItem("sesion");
    navigate("/");
  }

  let sesion = null;

  try {
    const datos = sessionStorage.getItem("sesion");

    if (datos) {
      sesion = JSON.parse(datos);
    }
  } catch (error) {
    console.error("Error al leer la sesión:", error);
  }

  return (
    <header className="encabezado">
      <div className="marca">
        <span className="marca-icono">SGI</span>

        <div>
          <strong>Sistema de Gestión</strong>
          <small>Inventario</small>
        </div>
      </div>

      <nav className="navegacion">
        <NavLink to="/inicio">Inicio</NavLink>

        <NavLink to="/productos">
          Productos
        </NavLink>

        <NavLink to="/movimientos">
          Movimientos
        </NavLink>

        <NavLink to="/usuarios">
          Usuarios
        </NavLink>
      </nav>

      <div className="zona-usuario">
        {sesion && (
          <div className="usuario-actual">
            <strong>{sesion.nombre}</strong>

            <small>
              {sesion.esDueno
                ? "Dueño"
                : sesion.esAdministrador
                ? "Administrador"
                : "Empleado"}
            </small>
          </div>
        )}

        <button
          type="button"
          className="boton boton-secundario"
          onClick={cerrarSesion}
        >
          Cerrar sesión
        </button>
      </div>
    </header>
  );
}