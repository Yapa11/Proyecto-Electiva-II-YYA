import { Navigate, Route, Routes } from "react-router-dom";

import InicioSesion from "../vistas/InicioSesion";
import Inicio from "../vistas/Inicio";
import Productos from "../vistas/Productos";
import FormularioProducto from "../vistas/FormularioProducto";
import Movimiento from "../vistas/Movimiento";
import Usuarios from "../vistas/Usuarios";
import PanelAdministrador from "../vistas/PanelAdministrador";

export default function RutasAplicacion(props) {
  const {
    sesion,
    negocioActual,
    negocios,
    usuarios,
    empleados,
    iniciarSesion,
    cerrarSesion,
    guardarProducto,
    eliminarProducto,
    registrarMovimiento,
    registrarEmpleado,
    designarAdministrador,
    revocarAdministrador,
    eliminarEmpleado
  } = props;

  /*
   * Si no existe sesión, solamente se permite
   * acceder al login.
   */
  if (!sesion) {
    return (
      <Routes>
        <Route
          path="/"
          element={
            <InicioSesion
              iniciarSesion={iniciarSesion}
            />
          }
        />

        <Route
          path="*"
          element={<Navigate to="/" replace />}
        />
      </Routes>
    );
  }

  /*
   * ADMINISTRADOR GLOBAL
   *
   * Solamente puede entrar al panel de consulta.
   */
  if (sesion.tipo === "administrador") {
    return (
      <Routes>
        <Route
          path="/administrador"
          element={
            <PanelAdministrador
              negocios={negocios}
              cerrarSesion={cerrarSesion}
            />
          }
        />

        <Route
          path="*"
          element={
            <Navigate
              to="/administrador"
              replace
            />
          }
        />
      </Routes>
    );
  }

  /*
   * DUEÑO O EMPLEADO
   */
  return (
    <Routes>
      <Route
        path="/inicio"
        element={
          <Inicio
            negocioActual={negocioActual}
            sesion={sesion}
          />
        }
      />

      <Route
        path="/productos"
        element={
          <Productos
            productos={negocioActual?.productos || []}
            puedeAdministrar={sesion.puedeAdministrar}
            eliminarProducto={eliminarProducto}
            sesion={sesion}
          />
        }
      />

      <Route
        path="/productos/nuevo"
        element={
          <FormularioProducto
            guardarProducto={guardarProducto}
            puedeAdministrar={sesion.puedeAdministrar}
          />
        }
      />

      <Route
        path="/productos/editar/:id"
        element={
          <FormularioProducto
            productos={negocioActual?.productos || []}
            guardarProducto={guardarProducto}
            puedeAdministrar={sesion.puedeAdministrar}
          />
        }
      />

      <Route
        path="/movimientos"
        element={
          <Movimiento
            productos={negocioActual?.productos || []}
            movimientos={
              negocioActual?.movimientos || []
            }
            registrarMovimiento={registrarMovimiento}
            puedeAdministrar={sesion.puedeAdministrar}
            sesion={sesion}
          />
        }
      />

      <Route
        path="/usuarios"
        element={
          <Usuarios
            usuarios={usuarios}
            empleados={empleados}
            esDueno={sesion.esDueno}
            registrarEmpleado={registrarEmpleado}
            designarAdministrador={
              designarAdministrador
            }
            revocarAdministrador={
              revocarAdministrador
            }
            eliminarEmpleado={eliminarEmpleado}
            sesion={sesion}
          />
        }
      />

      <Route
        path="*"
        element={<Navigate to="/inicio" replace />}
      />
    </Routes>
  );
}