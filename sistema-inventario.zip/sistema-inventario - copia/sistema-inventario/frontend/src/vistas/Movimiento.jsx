import { useState } from "react";

import DisenoPagina from "../componentes/DisenoPagina";


export default function Movimiento({

  productos = [],

  movimientos = [],

  registrarMovimiento,

  puedeAdministrar,

  sesion

}) {

  const [vista, setVista] =
    useState("historial");


  const [tipoMovimiento, setTipoMovimiento] =
    useState("Entrada");


  const [productoId, setProductoId] =
    useState("");


  const [cantidad, setCantidad] =
    useState("");


  const [fecha, setFecha] =
    useState(
      new Date()
        .toISOString()
        .slice(0, 10)
    );


  const [busqueda, setBusqueda] =
    useState("");


  const [filtroTipo, setFiltroTipo] =
    useState("Todos");


  const [mensaje, setMensaje] =
    useState("");


  function abrirEntrada() {

    setTipoMovimiento("Entrada");

    setVista("formulario");

    setMensaje("");

  }


  function abrirSalida() {

    setTipoMovimiento("Salida");

    setVista("formulario");

    setMensaje("");

  }


  function verMovimientos() {

    setVista("historial");

    setMensaje("");

  }


  function registrar(e) {

    e.preventDefault();

    setMensaje("");


    if (!puedeAdministrar) {

      setMensaje(
        "No tienes permisos para registrar movimientos. Solo el dueño o el empleado designado como administrador puede hacerlo."
      );

      return;

    }


    if (!productoId) {

      setMensaje(
        "Selecciona un producto."
      );

      return;

    }


    const cantidadNumero =
      Number(cantidad);


    if (
      !cantidadNumero ||
      cantidadNumero <= 0
    ) {

      setMensaje(
        "La cantidad debe ser mayor que cero."
      );

      return;

    }


    const producto =
      productos.find(
        (p) =>
          p.id ===
          Number(productoId)
      );


    if (!producto) {

      setMensaje(
        "El producto seleccionado no existe."
      );

      return;

    }


    if (
      tipoMovimiento === "Salida" &&
      cantidadNumero > producto.stock
    ) {

      setMensaje(
        `No hay suficiente stock. Disponible: ${producto.stock}.`
      );

      return;

    }


    registrarMovimiento(
      tipoMovimiento,
      {
        productoId,
        cantidad: cantidadNumero,
        fecha
      }
    );


    setMensaje(
      `${tipoMovimiento} registrada correctamente.`
    );


    setProductoId("");

    setCantidad("");

  }


  const movimientosFiltrados =
    movimientos.filter(
      (movimiento) => {

        const coincideTipo =
          filtroTipo === "Todos" ||
          movimiento.tipo ===
            filtroTipo;


        const texto =
          busqueda
            .toLowerCase()
            .trim();


        const coincideBusqueda =
          !texto ||
          movimiento.producto
            .toLowerCase()
            .includes(texto) ||
          movimiento.tipo
            .toLowerCase()
            .includes(texto) ||
          movimiento.fecha
            .includes(texto);


        return (
          coincideTipo &&
          coincideBusqueda
        );

      }
    );


  return (

    <DisenoPagina

      titulo="Movimientos"

      subtitulo={
        `Control de entradas, salidas y movimientos del negocio ${sesion?.negocioNombre || ""}`
      }

    >

      {/* BOTONES PRINCIPALES */}

      <div
        style={{
          display: "flex",
          gap: "12px",
          flexWrap: "wrap",
          marginBottom: "24px"
        }}
      >

        <button
          className="boton boton-principal"
          onClick={abrirEntrada}
        >
          + Registrar entrada
        </button>


        <button
          className="boton boton-peligro"
          onClick={abrirSalida}
        >
          - Registrar salida
        </button>


        <button
          className="boton boton-secundario"
          onClick={verMovimientos}
        >
          Ver movimientos
        </button>

      </div>


      {/* INFORMACIÓN DEL USUARIO */}

      <div
        style={{
          background: "#ffffff",
          border: "1px solid #e1e5ea",
          borderRadius: "12px",
          padding: "16px",
          marginBottom: "20px"
        }}
      >

        <strong>
          Sesión actual:
        </strong>

        {" "}

        {sesion?.nombre}

        {" — "}

        {sesion?.esDueno
          ? "Dueño"
          : sesion?.puedeAdministrar
            ? "Administrador"
            : "Empleado"}

      </div>


      {/* FORMULARIO */}

      {vista === "formulario" && (

        <div
          style={{
            background: "#ffffff",
            border: "1px solid #e1e5ea",
            borderRadius: "12px",
            padding: "24px",
            marginBottom: "24px"
          }}
        >

          <h2>
            Registrar {tipoMovimiento.toLowerCase()}
          </h2>


          {!puedeAdministrar && (

            <div
              style={{
                padding: "14px",
                background: "#fff4e5",
                borderRadius: "8px",
                marginBottom: "20px"
              }}
            >
              <strong>
                Acceso de solo consulta
              </strong>

              <p>
                Solamente el dueño del negocio
                o el empleado designado como
                administrador puede registrar
                entradas y salidas.
              </p>
            </div>

          )}


          {puedeAdministrar && (

            <form onSubmit={registrar}>

              <label>
                Producto
              </label>

              <select
                value={productoId}
                onChange={(e) =>
                  setProductoId(
                    e.target.value
                  )
                }
                required
              >

                <option value="">
                  Selecciona un producto
                </option>

                {productos.map(
                  (producto) => (

                    <option
                      key={producto.id}
                      value={producto.id}
                    >
                      {producto.nombre}
                      {" — Stock: "}
                      {producto.stock}
                    </option>

                  )
                )}

              </select>


              <label>
                Cantidad
              </label>

              <input
                type="number"
                min="1"
                value={cantidad}
                onChange={(e) =>
                  setCantidad(
                    e.target.value
                  )
                }
                placeholder="Ejemplo: 10"
                required
              />


              <label>
                Fecha
              </label>

              <input
                type="date"
                value={fecha}
                onChange={(e) =>
                  setFecha(
                    e.target.value
                  )
                }
                required
              />


              {mensaje && (

                <p
                  style={{
                    marginTop: "15px",
                    fontWeight: "600"
                  }}
                >
                  {mensaje}
                </p>

              )}


              <button
                type="submit"
                className="boton boton-principal"
              >
                Registrar {tipoMovimiento.toLowerCase()}
              </button>

            </form>

          )}


          {!puedeAdministrar && (

            <button
              className="boton boton-secundario"
              onClick={verMovimientos}
            >
              Volver a movimientos
            </button>

          )}

        </div>

      )}


      {/* HISTORIAL */}

      {vista === "historial" && (

        <div>

          <div
            style={{
              background: "#ffffff",
              border: "1px solid #e1e5ea",
              borderRadius: "12px",
              padding: "20px",
              marginBottom: "20px"
            }}
          >

            <h2>
              Historial de movimientos
            </h2>


            <div
              style={{
                display: "flex",
                gap: "12px",
                flexWrap: "wrap",
                marginTop: "15px"
              }}
            >

              <input
                type="text"
                placeholder="Buscar por producto, tipo o fecha..."
                value={busqueda}
                onChange={(e) =>
                  setBusqueda(
                    e.target.value
                  )
                }
                style={{
                  flex: "1",
                  minWidth: "250px"
                }}
              />


              <select
                value={filtroTipo}
                onChange={(e) =>
                  setFiltroTipo(
                    e.target.value
                  )
                }
              >

                <option value="Todos">
                  Todos
                </option>

                <option value="Entrada">
                  Entradas
                </option>

                <option value="Salida">
                  Salidas
                </option>

              </select>

            </div>

          </div>


          <div className="tabla-contenedor">

            <table>

              <thead>

                <tr>

                  <th>
                    Tipo
                  </th>

                  <th>
                    Producto
                  </th>

                  <th>
                    Cantidad
                  </th>

                  <th>
                    Fecha
                  </th>

                </tr>

              </thead>


              <tbody>

                {movimientosFiltrados.length === 0 ? (

                  <tr>

                    <td
                      colSpan="4"
                      style={{
                        textAlign: "center",
                        padding: "30px"
                      }}
                    >
                      No se encontraron
                      movimientos.
                    </td>

                  </tr>

                ) : (

                  movimientosFiltrados.map(
                    (movimiento) => (

                      <tr
                        key={
                          movimiento.id
                        }
                      >

                        <td>

                          <span
                            className={
                              `etiqueta ${
                                movimiento.tipo ===
                                "Entrada"
                                  ? "entrada"
                                  : "salida"
                              }`
                            }
                          >
                            {
                              movimiento.tipo
                            }
                          </span>

                        </td>


                        <td>
                          {
                            movimiento.producto
                          }
                        </td>


                        <td>
                          {
                            movimiento.cantidad
                          }
                        </td>


                        <td>
                          {
                            movimiento.fecha
                          }
                        </td>

                      </tr>

                    )
                  )

                )}

              </tbody>

            </table>

          </div>

        </div>

      )}

    </DisenoPagina>

  );

}