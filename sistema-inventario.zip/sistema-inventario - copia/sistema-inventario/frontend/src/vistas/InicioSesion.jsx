import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function InicioSesion({ iniciarSesion }) {
  const navigate = useNavigate();

  const [tipoAcceso, setTipoAcceso] = useState("dueno");
  const [codigoNegocio, setCodigoNegocio] = useState("");
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [mensaje, setMensaje] = useState("");

  function manejarCambioTipo(e) {
    const nuevoTipo = e.target.value;

    setTipoAcceso(nuevoTipo);
    setMensaje("");

    if (nuevoTipo === "administrador") {
      setCodigoNegocio("");
    }
  }

  function manejarInicioSesion(e) {
    e.preventDefault();

    setMensaje("");

    const resultado = iniciarSesion({
      tipoAcceso,
      codigoNegocio,
      correo,
      password
    });

    if (!resultado.correcto) {
      setMensaje(resultado.mensaje);
      return;
    }

    navigate(resultado.ruta);
  }

  return (
    <div className="pantalla-autenticacion">
      <div className="tarjeta-autenticacion">
        <div className="logo-grande">SGI</div>

        <h1>Sistema de Gestión de Inventario</h1>

        <p className="texto-centro">
          Ingresa con tus credenciales para continuar
        </p>

        <form onSubmit={manejarInicioSesion}>
          <label>Tipo de acceso</label>

          <select
            value={tipoAcceso}
            onChange={manejarCambioTipo}
            required
          >
            <option value="dueno">
              Dueño del negocio
            </option>

            <option value="empleado">
              Empleado
            </option>

            <option value="administrador">
              Administrador global
            </option>
          </select>

          {tipoAcceso !== "administrador" && (
            <>
              <label>Código del negocio</label>

              <input
                type="text"
                placeholder="Ejemplo: NEG001"
                value={codigoNegocio}
                onChange={(e) =>
                  setCodigoNegocio(
                    e.target.value.toUpperCase()
                  )
                }
                required
              />
            </>
          )}

          <label>Correo electrónico</label>

          <input
            type="email"
            placeholder="correo@ejemplo.com"
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
            required
          />

          <label>Contraseña</label>

          <input
            type="password"
            placeholder="********"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          {mensaje && (
            <div className="mensaje-error">
              {mensaje}
            </div>
          )}

          <button
            className="boton boton-principal boton-ancho"
            type="submit"
          >
            Iniciar sesión
          </button>
        </form>

        <div className="informacion-acceso">
          <strong>Accesos de prueba</strong>

          <p>
            <b>Administrador global:</b>
            <br />
            admin@sgi.com
            <br />
            Contraseña: 123456
          </p>

          <p>
            <b>Dueño NEG001:</b>
            <br />
            dueno@tecnoquibdo.com
            <br />
            Contraseña: 123456
          </p>

          <p>
            <b>Empleado NEG001:</b>
            <br />
            ana@tecnoquibdo.com
            <br />
            Contraseña: 123456
          </p>
        </div>
      </div>
    </div>
  );
}