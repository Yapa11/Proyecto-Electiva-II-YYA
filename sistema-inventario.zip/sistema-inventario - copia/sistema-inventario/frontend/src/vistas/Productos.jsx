import { useState } from "react";

import {
  Link
} from "react-router-dom";

import DisenoPagina from "../componentes/DisenoPagina";

import ModalConfirmacion
  from "../componentes/ModalConfirmacion";


export default function Productos({

  productos = [],

  eliminarProducto,

  puedeAdministrar

}) {

  const [busqueda, setBusqueda] =
    useState("");


  const [productoEliminar, setProductoEliminar] =
    useState(null);


  const productosFiltrados =
    productos.filter(
      (producto) => {

        const texto =
          busqueda
            .toLowerCase()
            .trim();


        return (

          producto.nombre
            .toLowerCase()
            .includes(texto)

          ||

          producto.categoria
            .toLowerCase()
            .includes(texto)

        );

      }
    );


  function confirmarEliminar() {

    if (!productoEliminar) {
      return;
    }


    eliminarProducto(
      productoEliminar.id
    );


    setProductoEliminar(null);

  }


  return (

    <DisenoPagina

      titulo="Productos"

      subtitulo="Consulta y administración del inventario"

    >

      <div
        style={{
          display: "flex",
          gap: "12px",
          alignItems: "center",
          flexWrap: "wrap",
          marginBottom: "20px"
        }}
      >

        <input
          type="text"
          placeholder="Buscar producto..."
          value={busqueda}
          onChange={(e) =>
            setBusqueda(
              e.target.value
            )
          }
          style={{
            flex: "1",
            minWidth: "250px"
          }}
        />


        {puedeAdministrar && (

          <Link
            to="/productos/nuevo"
            className="boton boton-principal"
          >
            + Nuevo producto
          </Link>

        )}

      </div>


      {!puedeAdministrar && (

        <div
          style={{
            background: "#fff4e5",
            border: "1px solid #f0d6a5",
            borderRadius: "8px",
            padding: "14px",
            marginBottom: "20px"
          }}
        >
          <strong>
            Modo de consulta
          </strong>

          <p>
            Tu usuario puede consultar los
            productos, pero solamente el dueño
            o el administrador designado puede
            modificarlos o eliminarlos.
          </p>

        </div>

      )}


      <div className="tabla-contenedor">

        <table>

          <thead>

            <tr>

              <th>
                Producto
              </th>

              <th>
                Categoría
              </th>

              <th>
                Precio
              </th>

              <th>
                Stock
              </th>

              <th>
                Estado
              </th>

              {puedeAdministrar && (

                <th>
                  Acciones
                </th>

              )}

            </tr>

          </thead>


          <tbody>

            {productosFiltrados.map(
              (producto) => {

                const stockBajo =
                  producto.stock <=
                  producto.minimo;


                return (

                  <tr
                    key={
                      producto.id
                    }
                  >

                    <td>
                      {
                        producto.nombre
                      }
                    </td>


                    <td>
                      {
                        producto.categoria
                      }
                    </td>


                    <td>
                      $
                      {Number(
                        producto.precio
                      ).toLocaleString(
                        "es-CO"
                      )}
                    </td>


                    <td>
                      {
                        producto.stock
                      }
                    </td>


                    <td>

                      {stockBajo ? (

                        <span className="etiqueta salida">
                          Stock bajo
                        </span>

                      ) : (

                        <span className="etiqueta entrada">
                          Disponible
                        </span>

                      )}

                    </td>


                    {puedeAdministrar && (

                      <td>

                        <div
                          style={{
                            display: "flex",
                            gap: "8px",
                            flexWrap: "wrap"
                          }}
                        >

                          <Link
                            to={`/productos/editar/${producto.id}`}
                            className="boton boton-secundario"
                          >
                            Editar
                          </Link>


                          <button
                            className="boton boton-peligro"
                            onClick={() =>
                              setProductoEliminar(
                                producto
                              )
                            }
                          >
                            Eliminar
                          </button>

                        </div>

                      </td>

                    )}

                  </tr>

                );

              }

            )}

          </tbody>

        </table>

      </div>


      {productoEliminar && (

        <ModalConfirmacion

          mensaje={
            `¿Deseas eliminar el producto "${productoEliminar.nombre}"?`
          }

          onConfirmar={
            confirmarEliminar
          }

          onCancelar={() =>
            setProductoEliminar(null)
          }

        />

      )}

    </DisenoPagina>

  );

}