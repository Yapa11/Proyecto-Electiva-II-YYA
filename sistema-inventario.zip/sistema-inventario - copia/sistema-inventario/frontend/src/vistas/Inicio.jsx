import DisenoPagina
  from "../componentes/DisenoPagina";

import TarjetaEstadistica
  from "../componentes/TarjetaEstadistica";

import TablaMovimientos
  from "../componentes/TablaMovimientos";


export default function Inicio({

  movimientos = [],

  productos = []

}) {

  const totalProductos =
    productos.length;


  const unidades =
    productos.reduce(
      (total, producto) =>
        total + producto.stock,
      0
    );


  const productosBajoStock =
    productos.filter(
      (producto) =>
        producto.stock <=
        producto.minimo
    ).length;


  return (

    <DisenoPagina

      titulo="Inicio"

      subtitulo="Resumen del inventario"

    >

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "20px",
          marginBottom: "25px"
        }}
      >

        <TarjetaEstadistica

          titulo="Productos"

          valor={
            totalProductos
          }

          detalle="Productos registrados"

        />


        <TarjetaEstadistica

          titulo="Unidades"

          valor={
            unidades
          }

          detalle="Unidades disponibles"

        />


        <TarjetaEstadistica

          titulo="Stock bajo"

          valor={
            productosBajoStock
          }

          detalle="Productos por reabastecer"

        />


        <TarjetaEstadistica

          titulo="Movimientos"

          valor={
            movimientos.length
          }

          detalle="Movimientos registrados"

        />

      </div>


      <div>

        <h2>
          Movimientos recientes
        </h2>

        <TablaMovimientos
          movimientos={
            movimientos.slice(0, 5)
          }
        />

      </div>

    </DisenoPagina>

  );

}